package deque;
import java.util.Iterator;

public class LinkedListDeque<T> implements Deque<T>, Iterable<T> {
    private class StuffNode {
        private T item;
        private StuffNode next;
        private StuffNode prev;

        private StuffNode(T i, StuffNode n, StuffNode p) {
            this.item = i;
            this.next = n;
            this.prev = p;
        }

        private StuffNode() {
        }
    }

    private StuffNode sentinel;
    private int size;

    //creates an empty list
    public LinkedListDeque() {
        sentinel = new StuffNode();
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        size = 0;
    }

    //Adds an item of type T to the front of the deque. You can assume that item is never null.
    @Override
    public void addFirst(T item) {
        sentinel.next = new StuffNode(item, sentinel.next, sentinel);
        sentinel.next.next.prev = sentinel.next;
        size++;
    }

    //Adds an item of type T to the back of the deque. You can assume that item is never null.
    @Override
    public void addLast(T item) {
        sentinel.prev = new StuffNode(item, sentinel, sentinel.prev);
        sentinel.prev.prev.next = sentinel.prev;
        size++;
    }

    //Returns the number of items in the deque.t
    @Override
    public int size() {
        return size;
    }

    //Prints the items in the deque from first to last, separated by a space.
    @Override
    public void printDeque() {
        StuffNode curr = sentinel.next;
        while (curr != sentinel) {
            System.out.print(curr.item + " ");
            curr = curr.next;
        } System.out.println("\n");
    }

    //Removes and returns the item at the front of the deque. If no such item exists, return null
    @Override
    public T removeFirst() {
        if (size == 0) {
            return null;
        } else {
            T first = sentinel.next.item;
            sentinel.next.next.prev = sentinel;
            sentinel.next = sentinel.next.next;
            size--;
            return first;
        }
    }

    //Removes and returns the item at the back of the deque. If no such item exists, return null
    @Override
    public T removeLast() {
        if (size == 0) {
            return null;
        } else {
            T last = sentinel.prev.item;
            sentinel.prev.prev.next = sentinel;
            sentinel.prev = sentinel.prev.prev;
            size--;
            return last;
        }
    }

    //Gets the item at the given index, where 0 is the front, 1 is the next item, and so forth.
    @Override
    public T get(int index) {
        int myIndex = 0;
        StuffNode curr = sentinel.next;
        while (myIndex < index) {
            if (index == 0 | index > size) {
                return null;
            } else {
                curr = curr.next;
                myIndex++;
            }
        } return curr.item;
    }

    //helper method for getRecursive that takes in the index, myIndex and curr node and
    // return the curr node when index equals to myindex
    private StuffNode realrecursive(int index, int myIndex, StuffNode curr) {
        if (index == myIndex) {
            return curr;
        } else {
            return realrecursive(index, myIndex + 1, curr.next);
        }
    }

    //Same as get, but uses recursion
    public T getRecursive(int index) {
        if (index < 0 || index >= size) {
            return null;
        } else {
            int myIndex = 0;
            StuffNode curr = sentinel.next;
            return realrecursive(index, myIndex, curr).item;
        }
    }

    // The Deque objects we’ll make are iterable (i.e. Iterable<T>)
    // so we must provide this method to return an iterator.
    public Iterator<T> iterator() {
        return new LinkedListIterator();
    }

    private class LinkedListIterator implements Iterator<T> {
        private StuffNode curr;

        LinkedListIterator() {
            curr = sentinel.next;
        }
        @Override
        public boolean hasNext() {
            if (curr == sentinel) {
                return false;
            }
            return true;
        }
        @Override
        public T next() {
            T returnItem = curr.item;
            curr = curr.next;
            return returnItem;
        }
    }

    //Returns whether or not the parameter o is equal to the Deque.
    // o is considered equal if it is a Deque and if it contains the same contents
    // (as goverened by the generic T’s equals method) in the same order.
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(o instanceof Deque)) {
            return false;
        }

        Deque<T> other = (Deque<T>) o;

        if (other.size() != this.size()) {
            return false;
        }
        for (int i = 0; i < this.size(); i++) {
            if (!(this.get(i).equals(other.get(i)))) {
                return false;
            }
        }
        return true;
    }
}
