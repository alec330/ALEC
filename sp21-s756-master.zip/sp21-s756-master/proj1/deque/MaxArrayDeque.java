package deque;
import java.util.Comparator;

public class MaxArrayDeque<T> extends ArrayDeque<T> {
    private Comparator<T> cmp;

    //creates a MaxArrayDeque with the given Comparator
    public MaxArrayDeque(Comparator<T> c) {
        super();
        cmp = c;
    }

    //returns the maximum element in the deque as governed
    //by the previously given Comparator. If the MaxArrayDeque is empty, simply return null.
    public T max() {
        if (this.isEmpty()) {
            return null;
        }
        int start = 0;
        int next = 1;
        int maxIndex = 0;
        while (next < this.size()) {
            if (this.get(start) == null) {
                start++;
            }
            if (this.get(next) == null) {
                next++;
            }
            if (cmp.compare(this.get(start), this.get(next)) < 0) {
                maxIndex = next;
                start = next;
                next++;
            }
            next++;
        }
        return this.get(maxIndex);
    }

    //returns the maximum element in the deque as governed by the parameter Comparator c.
    // If the MaxArrayDeque is empty, simply return null
    public T max(Comparator<T> c) {
        if (this.isEmpty()) {
            return null;
        }
        int start = 0;
        int next = 1;
        int maxIndex = 0;
        while (next < this.size()) {
            if (this.get(start) == null) {
                start++;
            }
            if (this.get(next) == null) {
                next++;
            }
            if (c.compare(this.get(start), this.get(next)) < 0) {
                maxIndex = next;
                start = next;
                next++;
            }
            next++;
        }
        return this.get(maxIndex);
    }
}
