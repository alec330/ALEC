package deque;
import java.util.Iterator;

public class ArrayDeque<T> implements Deque<T>, Iterable<T> {
    private int size;
    private T[] array;
    private int nextFirst;
    private int nextLast;
    private int factor;
    private double ratio;

    //creates an empty array
    public ArrayDeque() {
        array = (T[]) new Object[8];  //cast
        size = 0;
        nextFirst = 4;
        nextLast = 5;
        factor = 2;
        ratio = 0.25;
    }

    /** helper method to help circular the index for addFirst method */
    private int circularMinus(int index) {
        if (index - 1 < 0) {
            return array.length - 1;
        } else {
            return index - 1;
        }
    }

    /**  helper method to help circular the index for addLast method */
    private int circularAdd(int index) {
        if (index + 1 == array.length) {
            return 0;
        } else {
            return index + 1;
        }
    }

    //resizing the array if the size go out of bounds
    private void resize(int capacity) {
        T[] newArray = (T[]) new Object[capacity];
        int currfirst = circularAdd(nextFirst);
        for (int index = 0; index < size; index++) {
            newArray[index] = array[currfirst];
            currfirst = circularAdd(currfirst);
        }
        array = newArray;
        nextLast = size;
        nextFirst = array.length - 1;
    }

    //Adds an item of type T to the front of the deque. You can assume that item is never null.
    @Override
    public void addFirst(T item) {
        if (size == array.length) {
            resize(size * factor);
        }
        array[nextFirst] = item;
        nextFirst = circularMinus(nextFirst);
        size++;
    }

    //Adds an item of type T to the back of the deque. You can assume that item is never null.
    @Override
    public void addLast(T item) {
        if (size == array.length) {
            resize(size * factor);
        }
        array[nextLast] = item;
        nextLast = circularAdd(nextLast);
        size++;
    }


    //Returns the number of items in the deque.
    @Override
    public int size() {
        return size;
    }

    //Prints the items in the deque from first to last, separated by a space.
    // Once all the items have been printed, print out a new line.
    @Override
    public void printDeque() {
        int currFirst = circularAdd(nextFirst); //get the last nextFirst item that we added or null
        while (currFirst != nextLast) { //hits the nextLast item we will be hitting the end
            if (array[currFirst] != null) {
                System.out.print(array[currFirst] + " ");
            }
            currFirst = circularAdd(currFirst);
        } System.out.print("\n");
    }

    //Removes and returns the item at the front of the deque. If no such item exists, returns null.
    @Override
    public T removeFirst() {
        if (size == 0) {
            return null;
        }
        int currFirst = circularAdd(nextFirst); // get the last nextFirst item that we added
        T removeItem = array[currFirst];
        array[currFirst] = null; //setting the last nextFirst item to null
        nextFirst = currFirst;
        size--;

        if (array.length >= 16 && size < array.length * ratio) {
            resize(array.length / factor);
        }

        return removeItem;
    }

    //removes and returns the items at the back of the deque. If no such item exists, returns null
    @Override
    public T removeLast() {
        if (size == 0) {
            return null;
        }
        int currLast = circularMinus(nextLast);
        T removeItem = array[currLast];
        array[currLast] = null;
        nextLast = currLast;
        size--;

        if (array.length >= 16 && size < array.length * ratio) {
            resize(array.length / factor);
        }

        return removeItem;
    }

    //Gets the item at the given index, where 0 is the front, 1 is the next item, and so forth.
    // If no such item exists, returns null. Must not alter the deque!
    @Override
    public T get(int index) {
        if (size == 0 | index > size) {
            return null;
        } else {
            int currfirst = circularAdd(nextFirst);
            for (int x = 0; x < index; x++) { //constant time?
                currfirst = circularAdd(currfirst);
            } return array[currfirst];
        }
    }

    //Returns whether or not the parameter o is equal to the Deque.
    // o is considered equal if it is a Deque and if it contains the same contents
    // (as goverened by the generic T’s equals method) in the same order.
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(o instanceof Deque)) {
            return false;
        }

        Deque<T> other = (Deque<T>) o;

        if (other.size() != this.size()) {
            return false;
        }
        for (int i = 0; i < this.size(); i++) { //change
            if (!(this.get(i).equals(other.get(i)))) {
                return false;
            }
        }
        return true;
    }

    // The Deque objects we’ll make are iterable (i.e. Iterable<T>)
    // so we must provide this method to return an iterator.
    // The Deque objects we’ll make are iterable (i.e. Iterable<T>)
    // so we must provide this method to return an iterator.
    public Iterator<T> iterator() {
        return new ArrayListIterator();
    }

    private class ArrayListIterator implements Iterator<T> {
        private int currfirst;
        private int number;

        ArrayListIterator() {
            currfirst = circularAdd(nextFirst);
            number = 0;
        }
        @Override
        public boolean hasNext() {
            if (number >= size) {
                return false;
            }
            return true;
        }
        @Override
        public T next() {
            T returnItem = array[currfirst];
            currfirst = circularAdd(currfirst);
            number += 1;
            return returnItem;
        }
    }
}


