package bstmap;

import java.util.Iterator;
import java.util.Set;

public class BSTMap<K extends Comparable<K>, V> implements Map61B<K, V> {
    private BSTNode root;

    private class BSTNode {
        private K key;           // sorted by key
        private V val;         // associated data
        private BSTNode left, right;  // left and right subtrees
        private int size;          // number of nodes in subtree

        public BSTNode(K key, V val, int size) {
            this.key = key;
            this.val = val;
            this.size = size;
        }
    }

    public void clear() {
        root = null;
    }

    public boolean containsKey(K key) {
        if (root == null) {
            return false;
        } else if (root.val == null && key != null) {
            return true;
        }
        return get(key) != null;
    }

    public V get(K key) {
        return get(key, root);
    }

    private V get(K key, BSTNode n) {
        if (n == null) {
            return null;
        }
        int cmp = key.compareTo(n.key);
        if (cmp < 0) {
            return get(key, n.left);
        } else if (cmp > 0) {
            return get(key, n.right);
        }
        return n.val;
    }

    public int size() {
        return size(root);
    }

    private int size(BSTNode n) {
        if (n == null) {
            return 0;
        }
        return n.size;
    }

    public void put(K key, V value) { /** create a private recursive method */
        root = put(key, value, root);
    }

    private BSTNode put(K key, V value, BSTNode n) {
        if (n == null) {
            return new BSTNode(key, value, 1);
        }
        int cmp = key.compareTo(n.key);
        if (cmp < 0) {
            n.left = put(key, value, n.left);
        } else if (cmp > 0){
            n.right = put(key, value, n.right);
        } else {
            n.val = value;
        }
        n.size = 1 + size(n.left) + size(n.right);
        return n;
    }

    public void printInOrder() {
        if (root == null) {
            System.out.println("None");
        }
        printInOrder(root);
    }

    private void printInOrder(BSTNode n) {
        if (n.left == null && n.right == null) {
            System.out.println(" " + n.key.toString());
        } else if (n.left != null && n.right == null) {
            printInOrder(n.left);
            System.out.println(" " + n.key.toString());
        } else if (n.left == null && n.right != null) {
            printInOrder(n.right);
            System.out.println(" " + n.key.toString());
        }
        printInOrder(n.left);
        System.out.println(" " + n.key.toString());
        printInOrder(n.right);
    }

    public Iterator<K> iterator() {
        throw new UnsupportedOperationException("Unavailable");
    }

    public Set<K> keySet() {
        throw new UnsupportedOperationException("Unavailable");
    }

    public V remove(K key) {
        throw new UnsupportedOperationException("Unavailable");
    }

    public V remove(K key, V value) {
        throw new UnsupportedOperationException("Unavailable");
    }
}
