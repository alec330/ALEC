package byow.lab12;
import org.junit.Test;
import static org.junit.Assert.*;

import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;

import java.util.Random;

/**
 * Draws a world consisting of hexagonal regions.
 */
public class HexWorld {
    private static final int WIDTH = 50;
    private static final int HEIGHT = 50;

    public static TETile[][] addHexagon(int sideLength) {
        TETile[][] myWorld = initialize();
        int rectLength = rectLength(sideLength);
        int rectWidth = rectWidth(sideLength);
        for (int x = 0; x < rectLength; x += 1) {
            for (int y = 0; y < rectWidth; y += 1) {
                myWorld[x][y] = Tileset.WALL;
            }
        }

        return myWorld;
    }

    public static int rectLength(int hexLength) {
        return hexLength * 2 + (hexLength - 2);
    }

    public static int rectWidth(int hexLength) {
        return hexLength * 2;
    }

    public static TETile[][] initialize() {
        TETile[][] world = new TETile[WIDTH][HEIGHT];
        for (int x = 0; x < WIDTH; x += 1) {
            for (int y = 0; y < HEIGHT; y += 1) {
                world[x][y] = Tileset.NOTHING;
            }
        }
        return world;
    }

    public static void main(String[] args) {
        TERenderer ter = new TERenderer();
        ter.initialize(WIDTH, HEIGHT);
        ter.renderFrame(addHexagon(3));
    }

}
