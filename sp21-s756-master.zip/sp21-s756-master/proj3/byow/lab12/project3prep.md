# Project 3 Prep

**For tessellating hexagons, one of the hardest parts is figuring out where to place each hexagon/how to easily place hexagons on screen in an algorithmic way.
After looking at your own implementation, consider the implementation provided near the end of the lab.
How did your implementation differ from the given one? What lessons can be learned from it?**

Answer: My implementation only consider the hexagon below the current hexagon, and it did not consider the ones that is on the bottom right like the lab did. 
Therefore, my implementation did not quite work because of this. The lesson learned is that I only draw the very big picture of the outcome, instead of breaking
it down into smaller pieces. 

-----

**Can you think of an analogy between the process of tessellating hexagons and randomly generating a world using rooms and hallways?
What is the hexagon and what is the tesselation on the Project 3 side?**

Answer: Tessellating hexagons is equivalent to combining the rooms and hallways when randomly generating a world. In here,
the hexagons are the rooms and the hallways, while the tesselation is the process of thinking how to randomly combine the rooms and hallways.

-----
**If you were to start working on world generation, what kind of method would you think of writing first? 
Think back to the lab and the process used to eventually get to tessellating hexagons.**

Answer: If I were to start working on world generation, I would consider building a room and a hallway separately first.
Just like the lab, it drew a hexagons separately first before combining the hexagons together. And I would need to consider the positioning of the hallways and the rooms.
Otherwise, it would generate some errors. After that, I can proceed to tessellating the rooms and the hallways.

-----
**What distinguishes a hallway from a room? How are they similar?**

Answer: The thing that distinguishes a hallway from a room is that hallway can only have a width of 1 or 2 tiles.
While a room has no limit of width. they are also similar because they are both surrounded by walls, and technically rooms can be identified as hallways.
