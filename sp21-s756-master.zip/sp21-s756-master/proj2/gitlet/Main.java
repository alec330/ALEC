package gitlet;

import static gitlet.Utils.error;

/** Driver class for Gitlet, a subset of the Git version-control system.
 *  @author Alec Luk
 */
public class Main {

    /** Usage: java gitlet.Main ARGS, where ARGS contains
     *  <COMMAND> <OPERAND1> <OPERAND2> ... 
     */
    public static void main(String[] args) {
        // TODO: what if args is empty?
        if (args.length == 0) {
            gitlet.Utils.message("Please enter a command.");
            System.exit(0);
        }
        String firstArg = args[0];
        switch(firstArg) {
            case "init":
                // handle the `init` command. example call: init
                Repository.setupPersistence();
                Repository.init();
                break;
            case "add":
                // handle the `add [filename]` command. example call: add filename.txt
                checkGitletexists();
                Repository.add(args[1]);
                break;
            case "commit":
                checkGitletexists();
                Repository.commit(args[1]);
                break;
            case "rm":
                checkGitletexists();
                Repository.rm(args[1]);
                break;
            case "log":
                checkGitletexists();
                Repository.log();
                break;
            case "global-log":
                checkGitletexists();
                Repository.globalLog();
                break;
            case "find":
                checkGitletexists();
                if (args.length > 2) { /** find initial commit. */
                    String message = null;
                    for (int i = 1; i < args.length; i++) {
                        message += args[i];
                    }
                    Repository.find(message);
                } else {
                    Repository.find(args[1]);
                }
                break;
            case "status":
                checkGitletexists();
                Repository.status();
                break;
            case "checkout":
                checkGitletexists();
                if (args.length == 2) {
                    Repository.checkoutBranch(args[1]);
                } else if (args.length == 3 && args[1].equals("--")) { /** checkout -- filename. */
                    Repository.checkoutOnlyFile(args[2]);
                } else if (args.length == 4 && args[2].equals("--")) { /** checkout commitHash -- filename .*/
                    Repository.checkoutcommitFile(args[1], args[3]);
                } else {
                    gitlet.Utils.message("Incorrect operands");
                    System.exit(0);
                }
                break;
            case "branch":
                checkGitletexists();
                Repository.branch(args[1]);
                break;
            case "rm-branch":
                checkGitletexists();
                Repository.rmBranch(args[1]);
                break;
            case "reset":
                checkGitletexists();
                Repository.reset(args[1]);
                break;
            case "merge":
                checkGitletexists();
                Repository.merge(args[1]);
                break;
            default:
                checkGitletexists();
                gitlet.Utils.message("No command with that name exists.");
                System.exit(0);
        }
        return;
    }

    public static void checkGitletexists() {
        if (!Repository.GITLET_DIR.exists()) {
            gitlet.Utils.message("Not in an initialized Gitlet directory.");
            System.exit(0);
        }
    }
}


