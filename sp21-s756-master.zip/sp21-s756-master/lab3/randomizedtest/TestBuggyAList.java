package randomizedtest;

import edu.princeton.cs.algs4.StdRandom;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestBuggyAList {
    @Test
    public void testThreeAddThreeRemove() {
        AListNoResizing<Integer> A = new AListNoResizing<>();
        BuggyAList<Integer> B = new BuggyAList<>();

        A.addLast(5);
        A.addLast(10);
        A.addLast(15);

        B.addLast(5);
        B.addLast(10);
        B.addLast(15);

        assertEquals(A.size(), B.size());

        assertEquals(A.removeLast(), B.removeLast());
        assertEquals(A.removeLast(), B.removeLast());
        assertEquals(A.removeLast(), B.removeLast());
    }

    @Test
    public void randomizedTest() {
        AListNoResizing<Integer> L = new AListNoResizing<>();
        BuggyAList<Integer> M = new BuggyAList<>();

        int N = 5000;
        for (int i = 0; i < N; i += 1) {
            int operationNumber = StdRandom.uniform(0, 4);
            if (operationNumber == 0) {
                // addLast
                int randVal = StdRandom.uniform(0, 100);
                L.addLast(randVal);
                M.addLast(randVal);
                System.out.println("addLast(" + randVal + ")");
            } else if (operationNumber == 1) {
                // size
                int size = L.size();
                int sizeM = M.size();
                System.out.println("size: " + size);
            } else if (L.size() > 0 & M.size() > 0 & operationNumber == 2) {
                assertEquals(L.getLast(), M.getLast());
            } else if (L.size() > 0 & M.size() > 0 & operationNumber == 3) {
                assertEquals(L.removeLast(), M.removeLast());
            }
        }
    }
}


