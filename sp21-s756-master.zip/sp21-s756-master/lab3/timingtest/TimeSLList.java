package timingtest;
import edu.princeton.cs.algs4.Stopwatch;

/**
 * Created by hug.
 */
public class TimeSLList {
    private static void printTimingTable(AList<Integer> Ns, AList<Double> times, AList<Integer> opCounts) {
        System.out.printf("%12s %12s %12s %12s\n", "N", "time (s)", "# ops", "microsec/op");
        System.out.printf("------------------------------------------------------------\n");
        for (int i = 0; i < Ns.size(); i += 1) {
            int N = Ns.get(i);
            double time = times.get(i);
            int opCount = opCounts.get(i);
            double timePerOp = time / opCount * 1e6;
            System.out.printf("%12d %12.2f %12d %12.2f\n", N, time, opCount, timePerOp);
        }
    }

    public static void main(String[] args) {
        timeGetLast();
    }

    public static void timeGetLast() {
        AList<Integer> Ns = new AList<>();
        AList<Double> times = new AList<>();
        AList<Integer> opCounts = new AList<>();

        SLList A = new SLList ();
        for (int i = 0; i < 1000; i++) {
            A.addLast(1);
        }
        Stopwatch sw1 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            A.getLast();
        }
        double timeinseconds1 = sw1.elapsedTime();
        Ns.addLast(1000);
        times.addLast(timeinseconds1);
        opCounts.addLast(10000);

        SLList B = new SLList ();
        for (int i = 0; i < 2000; i++) {
            B.addLast(1);
        }
        Stopwatch sw2 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            B.getLast();
        }
        double timeinseconds2 = sw2.elapsedTime();
        Ns.addLast(2000);
        times.addLast(timeinseconds2);
        opCounts.addLast(10000);

        SLList C = new SLList ();
        for (int i = 0; i < 4000; i++) {
            C.addLast(1);
        }
        Stopwatch sw3 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            C.getLast();
        }
        double timeinseconds3 = sw3.elapsedTime();
        Ns.addLast(4000);
        times.addLast(timeinseconds3);
        opCounts.addLast(10000);

        SLList D = new SLList ();
        for (int i = 0; i < 8000; i++) {
            D.addLast(1);
        }
        Stopwatch sw4 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            D.getLast();
        }
        double timeinseconds4 = sw4.elapsedTime();
        Ns.addLast(8000);
        times.addLast(timeinseconds4);
        opCounts.addLast(10000);

        SLList E = new SLList ();
        for (int i = 0; i < 16000; i++) {
            E.addLast(1);
        }
        Stopwatch sw5 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            E.getLast();
        }
        double timeinseconds5 = sw5.elapsedTime();
        Ns.addLast(16000);
        times.addLast(timeinseconds5);
        opCounts.addLast(10000);

        SLList F = new SLList ();
        for (int i = 0; i < 32000; i++) {
            F.addLast(1);
        }
        Stopwatch sw6 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            F.getLast();
        }
        double timeinseconds6 = sw6.elapsedTime();
        Ns.addLast(32000);
        times.addLast(timeinseconds6);
        opCounts.addLast(10000);

        SLList G = new SLList ();
        for (int i = 0; i < 64000; i++) {
            G.addLast(1);
        }
        Stopwatch sw7 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            G.getLast();
        }
        double timeinseconds7 = sw7.elapsedTime();
        Ns.addLast(64000);
        times.addLast(timeinseconds7);
        opCounts.addLast(10000);

        SLList H = new SLList ();
        for (int i = 0; i < 128000; i++) {
            H.addLast(1);
        }
        Stopwatch sw8 = new Stopwatch();
        for (int j = 0; j < 10000; j ++) {
            H.getLast();
        }
        double timeinseconds8 = sw8.elapsedTime();
        Ns.addLast(128000);
        times.addLast(timeinseconds8);
        opCounts.addLast(10000);

        printTimingTable(Ns, times, opCounts);
    }

}
