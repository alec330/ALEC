package timingtest;
import edu.princeton.cs.algs4.Stopwatch;

/**
 * Created by hug.
 */
public class TimeAList {
    private static void printTimingTable(AList<Integer> Ns, AList<Double> times, AList<Integer> opCounts) {
        System.out.printf("%12s %12s %12s %12s\n", "N", "time (s)", "# ops", "microsec/op");
        System.out.printf("------------------------------------------------------------\n");
        for (int i = 0; i < Ns.size(); i += 1) {
            int N = Ns.get(i);
            double time = times.get(i);
            int opCount = opCounts.get(i);
            double timePerOp = time / opCount * 1e6;
            System.out.printf("%12d %12.2f %12d %12.2f\n", N, time, opCount, timePerOp);
        }
    }

    public static void main(String[] args) {
        timeAListConstruction();
    }

    public static void timeAListConstruction() {
        AList<Integer> Ns = new AList<>();
        AList<Double> times = new AList<>();
        AList<Integer> opCounts = new AList<>();

        Stopwatch sw1 = new Stopwatch();
        AList A = new AList();
        for (int i = 0; i < 1000; i++) {
            A.addLast(1);
        }
        double timeinseconds1 = sw1.elapsedTime();
        Ns.addLast(1000);
        times.addLast(timeinseconds1);
        opCounts.addLast(1000);

        Stopwatch sw2 = new Stopwatch();
        AList B = new AList();
        for (int i = 0; i < 2000; i++) {
            B.addLast(1);
        }
        double timeinseconds2 = sw2.elapsedTime();
        Ns.addLast(2000);
        times.addLast(timeinseconds2);
        opCounts.addLast(2000);

        Stopwatch sw3 = new Stopwatch();
        AList C = new AList();
        for (int i = 0; i < 4000; i++) {
            C.addLast(1);
        }
        double timeinseconds3 = sw3.elapsedTime();
        Ns.addLast(4000);
        times.addLast(timeinseconds3);
        opCounts.addLast(4000);

        Stopwatch sw4 = new Stopwatch();
        AList D = new AList();
        for (int i = 0; i < 8000; i++) {
            D.addLast(1);
        }
        double timeinseconds4 = sw4.elapsedTime();
        Ns.addLast(8000);
        times.addLast(timeinseconds4);
        opCounts.addLast(8000);

        Stopwatch sw5 = new Stopwatch();
        AList E = new AList();
        for (int i = 0; i < 16000; i++) {
            E.addLast(1);
        }
        double timeinseconds5 = sw5.elapsedTime();
        Ns.addLast(16000);
        times.addLast(timeinseconds5);
        opCounts.addLast(16000);

        Stopwatch sw6 = new Stopwatch();
        AList F = new AList ();
        for (int i = 0; i < 32000; i++) {
            F.addLast(1);
        }
        double timeinseconds6 = sw6.elapsedTime();
        Ns.addLast(32000);
        times.addLast(timeinseconds6);
        opCounts.addLast(32000);

        Stopwatch sw7 = new Stopwatch();
        AList G = new AList();
        for (int i = 0; i < 64000; i++) {
            G.addLast(1);
        }
        double timeinseconds7 = sw7.elapsedTime();
        Ns.addLast(64000);
        times.addLast(timeinseconds7);
        opCounts.addLast(64000);

        Stopwatch sw8 = new Stopwatch();
        AList H = new AList();
        for (int i = 0; i < 128000; i++) {
            H.addLast(1);
        }
        double timeinseconds8 = sw8.elapsedTime();
        Ns.addLast(128000);
        times.addLast(timeinseconds8);
        opCounts.addLast(128000);

        printTimingTable(Ns, times, opCounts);
    }
}
